import { Module } from '@nestjs/common';
import { TypeOrmModule } from '@nestjs/typeorm';
import { AppController } from './app.controller';
import { AppService } from './app.service';

// Módulos
import { AlunoModule } from './aluno/aluno.module';
import { CursoModule } from './curso/curso.module';
import { MatriculaModule } from './matricula/matricula.module';
import { FinanceiroModule } from './financeiro/financeiro.module';

// Entidades
import { Aluno } from './entities/aluno.entity';
import { Curso } from './entities/curso.entity';
import { Matricula } from './entities/matricula.entity';
import { MatriculaTermo } from './entities/matricula-termo.entity';
import { Financeiro } from './entities/financeiro.entity';
import { Aula } from './entities/aula.entity';

@Module({
  imports: [
    TypeOrmModule.forRoot({
      type: 'sqlite',
      database: 'db.sqlite', // <--- É AQUI QUE ELE CRIA O ARQUIVO
      entities: [Aluno, Aula, Curso, Matricula, MatriculaTermo, Financeiro],
      synchronize: true, // Isso cria as tabelas automaticamente
    }),
    AlunoModule,
    CursoModule,
    MatriculaModule,
    FinanceiroModule,
  ],
  controllers: [AppController],
  providers: [AppService],
})
export class AppModule {}
